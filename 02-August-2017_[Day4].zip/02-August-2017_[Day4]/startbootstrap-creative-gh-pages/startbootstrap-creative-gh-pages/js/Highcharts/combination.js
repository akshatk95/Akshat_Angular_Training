Highcharts.chart('container3', {
    title: {
        text: 'Combination chart'
    },
    xAxis: {
        categories: ['Apples', 'Oranges', 'Mangoes', 'Bananas']
    },
    labels: {
        items: [{
            html: 'Total fruit consumption',
            style: {
                left: '50px',
                top: '18px',
                color: (Highcharts.theme && Highcharts.theme.textColor) || 'black'
            }
        }]
    },
    series: [{
        "type": "column",
        "name": "A",
        "data": [3, 2, 1, 3]
    }, {
        "type": "column",
        "name": "B",
        "data": [2, 3, 5, 7]
    }, {
        "type": "column",
        "name": "C",
        "data": [4, 3, 3, 9]
    }, {
        "type": "spline",
        "name": "Average",
        "data": [3, 2.67, 3, 6.33],
        "marker": {
            "lineWidth": 2,
            "lineColor": Highcharts.getOptions().colors[3],
            "fillColor": "white"
        }
    }, {
        "type": "pie",
        "name": "Total consumption",
        "data": [{
            "name": "A",
            "y": 9,
            "color": Highcharts.getOptions().colors[0] // Jane's color
        }, {
            "name": "B",
            "y": 17,
            "color": Highcharts.getOptions().colors[1] // John's color
        }, {
            "name": "C",
            "y": 19,
            "color": Highcharts.getOptions().colors[2] // Joe's color
        }],
        center: [100, 80],
        size: 100,
        showInLegend: false,
        dataLabels: {
            enabled: false
        }
    }]
});