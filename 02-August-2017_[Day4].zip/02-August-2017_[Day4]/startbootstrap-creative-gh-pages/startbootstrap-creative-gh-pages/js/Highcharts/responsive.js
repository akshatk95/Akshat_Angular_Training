var chart = Highcharts.chart('container2', {

    chart: {
        type: 'column'
    },

    title: {
        text: 'Highcharts responsive chart'
    },

    subtitle: {
        text: 'Resize the frame or click buttons to change appearance'
    },

    legend: {
            align: 'right',
                  verticalAlign: 'middle',
                             layout: 'vertical'
    },

    xAxis: {
        categories: ['Apples', 'Oranges', 'Bananas','Mangoes'],
        labels: {
            x: -10
        }
    },

    yAxis: {
        allowDecimals: false,
        title: {
            text: 'Amount'
        }
    },

    series: [{
        "name": "A",
        "data": [1, 4, 3, 2]
    }, {
        "name": "B",
        "data": [6, 4, 2, 5]
    }, {
        "name": "C",
        "data": [8, 4, 3, 2]
    }],

    responsive: {
        rules: [{
            condition: {
                maxWidth: 500
            },
            chartOptions: {
                legend: {
                    align: 'center',
                    verticalAlign: 'bottom',
                    layout: 'horizontal'
                },
                yAxis: {
                    labels: {
                        align: 'left',
                        x: 0,
                        y: -5
                    },
                    title: {
                        text: null
                    }
                },
                subtitle: {
                    text: null
                },
                credits: {
                    enabled: false
                }
            }
        }]
    }
});