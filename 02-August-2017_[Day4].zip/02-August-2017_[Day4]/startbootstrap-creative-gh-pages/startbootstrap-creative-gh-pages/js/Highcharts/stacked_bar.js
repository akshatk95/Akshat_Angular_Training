Highcharts.chart('container1', {
    chart: {
        type: 'bar'
    },
    title: {
        text: 'Stacked bar chart'
    },
    xAxis: {
        categories: ['Apples', 'Oranges', 'Mangoes', 'Bananas']
    },
    yAxis: {
        min: 0,
        title: {
            text: 'Total fruit consumption'
        }
    },
    legend: {
        reversed: true
    },
    plotOptions: {
        series: {
            stacking: 'normal'
        }
    },
    series: [{
        "name": "A",
        "data": [5, 3, 4, 7]
    }, {
        "name": "B",
        "data": [2, 2, 3, 2]
    }, {
        "name": "C",
        "data": [3, 4, 4, 2]
    }]
});